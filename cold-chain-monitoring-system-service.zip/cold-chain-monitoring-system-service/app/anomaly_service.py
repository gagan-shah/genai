# app/anomaly_service.py
from datetime import datetime
from statistics import mean, pstdev
from typing import Dict, Any, List

from sqlalchemy.orm import Session
from . import models


def fetch_sensor_window(
    db: Session,
    sensor_id: int,
    start: datetime,
    end: datetime,
) -> List[models.SensorData]:
    return (
        db.query(models.SensorData)
        .filter(models.SensorData.sensor_id == sensor_id)
        .filter(models.SensorData.recorded_at >= start)
        .filter(models.SensorData.recorded_at <= end)
        .order_by(models.SensorData.recorded_at.asc())
        .all()
    )


def compute_anomalies_numeric(values: List[float]) -> Dict[str, Any]:
    """
    Basic statistics anomaly detection:
    - z-score spikes
    - oscillations via sign changes in first difference
    """
    if len(values) < 5:
        return {
            "is_anomalous": False,
            "reason": "not_enough_data",
            "details": {
                "mean": 0.0,
                "std": 0.0,
                "max_abs_z": 0.0,
                "num_high_z": 0,
                "oscillation_ratio": 0.0,
            },
        }

    mu = mean(values)
    sigma = pstdev(values) or 1e-6  # avoid divide by zero

    z_scores = [(v - mu) / sigma for v in values]
    high_z = [abs(z) for z in z_scores if abs(z) >= 3.0]

    diffs = [values[i + 1] - values[i] for i in range(len(values) - 1)]
    sign_changes = 0
    for i in range(len(diffs) - 1):
        if diffs[i] == 0 or diffs[i + 1] == 0:
            continue
        if (diffs[i] > 0 and diffs[i + 1] < 0) or (diffs[i] < 0 and diffs[i + 1] > 0):
            sign_changes += 1
    oscillation_ratio = sign_changes / max(len(diffs), 1)

    is_anom = bool(high_z or oscillation_ratio > 0.5)

    return {
        "is_anomalous": is_anom,
        "reason": "high_z_or_oscillation" if is_anom else "normal",
        "details": {
            "mean": mu,
            "std": sigma,
            "max_abs_z": max(abs(z) for z in z_scores),
            "num_high_z": len(high_z),
            "oscillation_ratio": oscillation_ratio,
        },
    }


def detect_sensor_anomalies(
    db: Session,
    sensor_id: int,
    start: datetime,
    end: datetime,
) -> Dict[str, Any]:
    sensor = db.query(models.Sensor).filter(models.Sensor.sensor_id == sensor_id).first()
    if sensor is None:
        return {"error": "sensor_not_found"}

    readings = fetch_sensor_window(db, sensor_id, start, end)

    # Ignore GPS and empty data
    if sensor.sensor_kind == models.SensorKind.GPS or not readings:
        return {
            "sensor_id": sensor_id,
            "sensor_kind": sensor.sensor_kind.value,
            "start": start.isoformat(),
            "end": end.isoformat(),
            "is_anomalous": False,
            "reason": "unsupported_or_no_data",
            "details": {
                "mean": 0.0,
                "std": 0.0,
                "max_abs_z": 0.0,
                "num_high_z": 0,
                "oscillation_ratio": 0.0,
            },
            "num_points": 0,
        }

    values = [
        float(r.value_number)
        for r in readings
        if r.value_number is not None
    ]

    stats = compute_anomalies_numeric(values)

    return {
        "sensor_id": sensor_id,
        "sensor_kind": sensor.sensor_kind.value,
        "start": start.isoformat(),
        "end": end.isoformat(),
        "is_anomalous": stats["is_anomalous"],
        "reason": stats["reason"],
        "details": stats["details"],
        "num_points": len(values),
    }
