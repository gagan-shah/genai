from sqlalchemy.orm import Session
from typing import List, Dict
from .database import get_db
from . import crud, schemas, models
# from langchain_openai import ChatOpenAI  # NEW
# from .llm_service import get_llm
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_google_genai import ChatGoogleGenerativeAI
from sqlalchemy.orm import Session
from .llm_service import get_llm
from .health_service import compute_package_health_ml
from datetime import datetime, timedelta
from fastapi import FastAPI, Depends,Body ,HTTPException, Query
from .anomaly_service import detect_sensor_anomalies
from .truck_alert_service import check_truck_sensor_breach, explain_truck_sensor_breach
from langchain_google_genai import ChatGoogleGenerativeAI

app = FastAPI(
    title="ColdChain AI Backend",
    description="APIs for trucks, packages, sensors, and AI analytics.",
    version="0.1.0",
)

@app.get(
    "/analytics/truck_sensor_breach_explain",
    response_model=schemas.TruckSensorBreachWithExplanation,
)
def get_truck_sensor_breach_explain(
    sensor_id: int = Query(..., description="Truck-level sensor ID"),
    lookback_minutes: int = Query(60, ge=5, le=240, description="History to inspect"),
    db: Session = Depends(get_db),
):
    result = check_truck_sensor_breach(db, sensor_id=sensor_id, lookback_minutes=lookback_minutes)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])

    explanation = explain_truck_sensor_breach(result)

    return schemas.TruckSensorBreachWithExplanation(
        **result,
        explanation=explanation,
    )

@app.get(
    "/analytics/truck_sensor_breach",
    response_model=schemas.TruckSensorBreach,
)
def get_truck_sensor_breach(
    sensor_id: int = Query(..., description="Truck-level sensor ID"),
    lookback_minutes: int = Query(60, ge=5, le=240, description="History to inspect"),
    db: Session = Depends(get_db),
):
    result = check_truck_sensor_breach(db, sensor_id=sensor_id, lookback_minutes=lookback_minutes)

    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])

    return schemas.TruckSensorBreach(**result)


@app.get(
    "/analytics/anomaly",
    response_model=schemas.AnomalyResult,
)
def anomaly_for_sensor(
    sensor_id: int = Query(..., description="Sensor ID to analyse"),
    hours: int = Query(1, ge=1, le=24, description="Lookback window in hours"),
    db: Session = Depends(get_db),
):
    end = datetime.utcnow()
    start = end - timedelta(hours=hours)

    result = detect_sensor_anomalies(db, sensor_id=sensor_id, start=start, end=end)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])

    return schemas.AnomalyResult(
        sensor_id=result["sensor_id"],
        sensor_kind=schemas.SensorKind(result["sensor_kind"]),
        start=result["start"],
        end=result["end"],
        is_anomalous=result["is_anomalous"],
        reason=result["reason"],
        details=schemas.AnomalyDetails(**result["details"]),
        num_points=result["num_points"],
    )

# @app.post("/llm/test")
# def test_llm(prompt: str, llm: ChatOpenAI = Depends(get_llm)):
#     resp = llm.invoke(prompt)
#     return {"output": resp.content}
@app.post("/llm/test")
def test_llm(
    prompt: str = Body(..., embed=True),
    llm: ChatGoogleGenerativeAI = Depends(get_llm),
):
    try:
        resp = llm.invoke(prompt)
        return {"output": resp.text}
    except Exception as e:
        # Temporary debug so you can see the real cause in logs
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/trucks/active", response_model=List[schemas.TruckStatus])
def list_active_trucks(db: Session = Depends(get_db)):
    rows = crud.get_active_truck_status(db)

    trucks_map: Dict[int, schemas.TruckStatus] = {}

    for truck, sensor, sensor_data in rows:
        if truck.truck_id not in trucks_map:
            trucks_map[truck.truck_id] = schemas.TruckStatus(
                truck_id=truck.truck_id,
                truck_code=truck.truck_code,
                registration_number=truck.registration_number,
                latest_readings=[],
            )

        trucks_map[truck.truck_id].latest_readings.append(
            schemas.SensorReading(
                sensor_id=sensor.sensor_id,
                sensor_kind=sensor.sensor_kind,  # FastAPI maps enum to schema enum
                recorded_at=sensor_data.recorded_at,
                value_number=float(sensor_data.value_number) if sensor_data.value_number is not None else None,
                value_lat=float(sensor_data.value_lat) if sensor_data.value_lat is not None else None,
                value_lng=float(sensor_data.value_lng) if sensor_data.value_lng is not None else None,
            )
        )

    return list(trucks_map.values())

@app.get(
    "/sensors/{sensor_id}/timeseries",
    response_model=List[schemas.SensorReading],
)
def get_sensor_timeseries(
    sensor_id: int,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    if limit <= 0 or limit > 1000:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 1000")

    readings = crud.get_sensor_timeseries(db, sensor_id=sensor_id, limit=limit)
    if not readings:
        return []

    # Need sensor kind for the schema; fetch once
    sensor = db.query(models.Sensor).filter(models.Sensor.sensor_id == sensor_id).first()
    if sensor is None:
        raise HTTPException(status_code=404, detail="Sensor not found")

    return [
        schemas.SensorReading(
            sensor_id=sensor_id,
            sensor_kind=sensor.sensor_kind,
            recorded_at=r.recorded_at,
            value_number=float(r.value_number) if r.value_number is not None else None,
            value_lat=float(r.value_lat) if r.value_lat is not None else None,
            value_lng=float(r.value_lng) if r.value_lng is not None else None,
        )
        for r in readings
    ]

@app.get(
    "/analytics/package_health",
    response_model=schemas.PackageHealth,
)
def get_package_health(
    package_id: int = Query(..., description="Package ID"),
    hours: int = Query(24, ge=1, le=168, description="Lookback window in hours"),
    db: Session = Depends(get_db),
):
    result = compute_package_health_ml(db, package_id=package_id, hours=hours)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])

    return schemas.PackageHealth(**result)