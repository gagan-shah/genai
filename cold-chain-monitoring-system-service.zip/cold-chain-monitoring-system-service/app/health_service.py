# app/health_service.py
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta

from sqlalchemy.orm import Session
from sklearn.linear_model import LogisticRegression
import numpy as np

from . import models

# ---------- DB helpers ----------

def get_package_sensors(db: Session, package_id: int) -> Tuple[Optional[models.Sensor], Optional[models.Sensor]]:
    temp_sensor = (
        db.query(models.Sensor)
        .filter(
            models.Sensor.package_id == package_id,
            models.Sensor.sensor_scope == models.SensorScope.PACKAGE,
            models.Sensor.sensor_kind == models.SensorKind.TEMPERATURE,
            models.Sensor.is_active == True,
        )
        .first()
    )

    hum_sensor = (
        db.query(models.Sensor)
        .filter(
            models.Sensor.package_id == package_id,
            models.Sensor.sensor_scope == models.SensorScope.PACKAGE,
            models.Sensor.sensor_kind == models.SensorKind.HUMIDITY,
            models.Sensor.is_active == True,
        )
        .first()
    )

    return temp_sensor, hum_sensor


def fetch_sensor_series(
    db: Session,
    sensor_id: int,
    start: datetime,
    end: datetime,
):
    return (
        db.query(models.SensorData)
        .filter(
            models.SensorData.sensor_id == sensor_id,
            models.SensorData.recorded_at >= start,
            models.SensorData.recorded_at <= end,
        )
        .order_by(models.SensorData.recorded_at.asc())
        .all()
    )

# ---------- Feature engineering ----------

def _compute_band_stats(
    readings: List[models.SensorData],
    min_val: Optional[float],
    max_val: Optional[float],
) -> Dict[str, Any]:
    if not readings:
        return {
            "num_points": 0,
            "pct_in_band": 0.0,
            "pct_low": 0.0,
            "pct_high": 0.0,
        }

    vals = [float(r.value_number) for r in readings if r.value_number is not None]
    if not vals:
        return {
            "num_points": 0,
            "pct_in_band": 0.0,
            "pct_low": 0.0,
            "pct_high": 0.0,
        }

    n = len(vals)
    in_band = 0
    low = 0
    high = 0

    for v in vals:
        if min_val is not None and v < min_val:
            low += 1
        elif max_val is not None and v > max_val:
            high += 1
        else:
            in_band += 1

    return {
        "num_points": n,
        "pct_in_band": in_band / n,
        "pct_low": low / n,
        "pct_high": high / n,
    }

def build_feature_vector(
    temp_stats: Dict[str, Any],
    hum_stats: Dict[str, Any],
) -> np.ndarray:
    """
    Build a numeric feature vector for ML model.
    Features (example):
      [temp_pct_in_band, temp_pct_low, temp_pct_high,
       hum_pct_in_band, hum_pct_low, hum_pct_high]
    """
    return np.array([
        temp_stats.get("pct_in_band", 0.0),
        temp_stats.get("pct_low", 0.0),
        temp_stats.get("pct_high", 0.0),
        hum_stats.get("pct_in_band", 0.0),
        hum_stats.get("pct_low", 0.0),
        hum_stats.get("pct_high", 0.0),
    ]).reshape(1, -1)

# ---------- Simple ML model (Logistic Regression) ----------

# In a real system you would train offline and load a persisted model.
# For hackathon/demo we train a toy model in-memory from synthetic rules.

_health_model: Optional[LogisticRegression] = None
_health_label_map = {0: "HEALTHY", 1: "AT_RISK", 2: "SPOILED_LIKELY"}

def _train_demo_model():
    """
    Train a toy classifier on synthetic examples using simple rules.
    """
    global _health_model

    # Synthetic dataset: rows of feature vectors and labels
    X = []
    y = []

    # Healthy examples (mostly in band)
    X.append([0.98, 0.01, 0.01, 0.97, 0.01, 0.02]); y.append(0)
    X.append([0.90, 0.05, 0.05, 0.92, 0.04, 0.04]); y.append(0)

    # At-risk examples (20–40% out of band)
    X.append([0.75, 0.10, 0.15, 0.70, 0.10, 0.20]); y.append(1)
    X.append([0.65, 0.20, 0.15, 0.60, 0.15, 0.25]); y.append(1)

    # Spoiled-likely examples (mostly out of band)
    X.append([0.30, 0.40, 0.30, 0.35, 0.35, 0.30]); y.append(2)
    X.append([0.10, 0.50, 0.40, 0.15, 0.45, 0.40]); y.append(2)

    X = np.array(X)
    y = np.array(y)

    model = LogisticRegression(multi_class="multinomial", max_iter=1000)
    model.fit(X, y)
    _health_model = model

def get_health_model() -> LogisticRegression:
    global _health_model
    if _health_model is None:
        _train_demo_model()
    return _health_model

# ---------- Main API logic ----------

def compute_package_health_ml(
    db: Session,
    package_id: int,
    hours: int = 24,
) -> Dict[str, Any]:
    now = datetime.utcnow()
    start = now - timedelta(hours=hours)

    pkg = db.query(models.Package).filter(models.Package.package_id == package_id).first()
    if not pkg:
        return {"error": "package_not_found"}

    temp_sensor, hum_sensor = get_package_sensors(db, package_id)

    temp_readings = []
    hum_readings = []

    if temp_sensor:
        temp_readings = fetch_sensor_series(db, temp_sensor.sensor_id, start, now)

    if hum_sensor:
        hum_readings = fetch_sensor_series(db, hum_sensor.sensor_id, start, now)

    temp_stats = _compute_band_stats(
        temp_readings,
        float(pkg.min_temp_c) if pkg.min_temp_c is not None else None,
        float(pkg.max_temp_c) if pkg.max_temp_c is not None else None,
    )
    hum_stats = _compute_band_stats(
        hum_readings,
        float(pkg.min_humidity_pc) if pkg.min_humidity_pc is not None else None,
        float(pkg.max_humidity_pc) if pkg.max_humidity_pc is not None else None,
    )

    X = build_feature_vector(temp_stats, hum_stats)
    model = get_health_model()
    proba = model.predict_proba(X)[0]
    label_idx = int(model.predict(X)[0])
    status = _health_label_map[label_idx]

    health_score = round(100.0 * proba[label_idx], 1)

    return {
        "package_id": package_id,
        "package_code": pkg.package_code,
        "product_sku": pkg.product_sku,
        "product_name": pkg.product_name,
        "window_hours": hours,
        "temp_stats": temp_stats,
        "hum_stats": hum_stats,
        "health_score": health_score,
        "health_status": status,
        "class_probabilities": {
            "HEALTHY": round(float(proba[0]), 3),
            "AT_RISK": round(float(proba[1]), 3),
            "SPOILED_LIKELY": round(float(proba[2]), 3),
        },
        "time_window": {
            "start": start.isoformat(),
            "end": now.isoformat(),
        },
    }
