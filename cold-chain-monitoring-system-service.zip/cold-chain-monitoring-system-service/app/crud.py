from sqlalchemy.orm import Session
from sqlalchemy import func
from . import models

def get_active_truck_status(db: Session):
    sub_latest = (
        db.query(
            models.SensorData.sensor_id,
            func.max(models.SensorData.recorded_at).label("max_ts"),
        )
        .group_by(models.SensorData.sensor_id)
        .subquery()
    )

    q = (
        db.query(models.Truck, models.Sensor, models.SensorData)
        .join(models.Sensor, models.Sensor.truck_id == models.Truck.truck_id)
        .join(
            sub_latest,
            sub_latest.c.sensor_id == models.Sensor.sensor_id,
        )
        .join(
            models.SensorData,
            (models.SensorData.sensor_id == sub_latest.c.sensor_id)
            & (models.SensorData.recorded_at == sub_latest.c.max_ts),
        )
        .filter(models.Sensor.sensor_scope == models.SensorScope.VEHICLE)
        .filter(models.Sensor.is_active == True)
    )

    return q.all()

def get_sensor_timeseries(db: Session, sensor_id: int, limit: int = 100):
    return (
        db.query(models.SensorData)
        .filter(models.SensorData.sensor_id == sensor_id)
        .order_by(models.SensorData.recorded_at.desc())
        .limit(limit)
        .all()
    )
