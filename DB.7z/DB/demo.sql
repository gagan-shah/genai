SELECT * FROM trip;
