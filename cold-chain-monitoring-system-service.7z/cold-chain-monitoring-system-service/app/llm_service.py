# # app/llm_service.py
# from functools import lru_cache
# from httpx import Client
# from langchain_openai import ChatOpenAI  # or from langchain.chat_models import ChatOpenAI
# import tiktoken
# import os
# import httpx

# tiktoken_cache_dir = "./token"

# os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir 
# client = httpx.Client(verify=False) 

# BASE_URL = "https://genailab.tcs.in"
# MODEL_NAME = "azure_ai/genailab-maas-DeepSeek-V3-0324"

# # For hackathon: you can keep the key in env var instead of hardcoding
# API_KEY = "sk-4i5NUtqUhxbRxNpLb039Hg"


# @lru_cache(maxsize=1)
# def get_http_client() -> Client:
#     # Reuse one HTTP client for performance
#     return Client(verify=False, timeout=60.0)


# @lru_cache(maxsize=1)
# def get_llm() -> ChatOpenAI:
#     client = get_http_client()
#     llm = ChatOpenAI(
#         base_url=BASE_URL,
#         model=MODEL_NAME,
#         api_key=API_KEY,
#         http_client=client,
#         temperature=0.1,
#     )
#     return llm

# app/llm_service.py
import os
from functools import lru_cache

from dotenv import load_dotenv
from httpx import Client
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()  # loads GEMINI_API_KEY from .env


@lru_cache(maxsize=1)
def get_http_client() -> Client:
    # Optional: you can pass this client to Gemini via `client` kwarg if needed
    return Client(timeout=60.0)


@lru_cache(maxsize=1)
def get_llm() -> ChatGoogleGenerativeAI:
    """
    Shared Gemini chat client for the whole app.
    Make sure GEMINI_API_KEY is set in your environment or .env file.
    """
    # gemini_api_key = os.getenv("GEMINI_API_KEY")
    # if not gemini_api_key:
    #     raise RuntimeError("GEMINI_API_KEY is not set in environment")

    llm = ChatGoogleGenerativeAI(
        model="gemini-2.5-flash",   # or any other Gemini model id you want
        google_api_key="AIzaSyCSi0utd5mmWvv5SmWw_Xjrd7kerLZ9HPI",
        temperature=0.1,
    )
    return llm
