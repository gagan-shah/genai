from pydantic import BaseModel
from datetime import datetime
from typing import Optional, List
from enum import Enum
from typing import Optional

class TripRoutePoint(BaseModel):
    recorded_at: datetime
    lat: float
    lng: float

class TripRoute(BaseModel):
    trip_id: int
    trip_code: str
    truck_id: int
    points: List[TripRoutePoint]

class SensorKind(str, Enum):
    TEMPERATURE = "TEMPERATURE"
    HUMIDITY = "HUMIDITY"
    GPS = "GPS"

class AnomalyDetails(BaseModel):
    mean: float
    std: float
    max_abs_z: float
    num_high_z: int
    oscillation_ratio: float

from typing import Optional

class TruckSensorBreach(BaseModel):
    sensor_id: int
    sensor_code: str
    sensor_kind: SensorKind

    min_value: Optional[float] = None
    max_value: Optional[float] = None
    breach_window_seconds: Optional[int] = None

    breach: bool
    breach_duration_seconds: Optional[float] = None
    breach_start: Optional[str] = None
    breach_end: Optional[str] = None

    reason: str

    class Config:
        from_attributes = True

class TruckSensorBreachWithExplanation(TruckSensorBreach):
    explanation: str

class AnomalyResult(BaseModel):
    sensor_id: int
    sensor_kind: SensorKind
    start: str
    end: str
    is_anomalous: bool
    reason: str
    details: AnomalyDetails
    num_points: int

class TruckBase(BaseModel):
    truck_id: int
    truck_code: str
    registration_number: Optional[str] = None

    class Config:
        from_attributes = True

class SensorReading(BaseModel):
    sensor_id: int
    sensor_kind: SensorKind
    recorded_at: datetime
    value_number: Optional[float] = None
    value_lat: Optional[float] = None
    value_lng: Optional[float] = None

    class Config:
        from_attributes = True

class TruckStatus(BaseModel):
    truck_id: int
    truck_code: str
    registration_number: Optional[str] = None

    latest_readings: List[SensorReading] = []

    current_lat: Optional[float] = None
    current_lng: Optional[float] = None

    trip_id: Optional[int] = None
    trip_code: Optional[str] = None
    trip_status: Optional[str] = None

    route_start: Optional[TripRoutePoint] = None
    route_end: Optional[TripRoutePoint] = None

class BandStats(BaseModel):
    num_points: int
    pct_in_band: float
    pct_low: float
    pct_high: float

class PackageHealth(BaseModel):
    package_id: int
    package_code: str
    product_sku: Optional[str] = None
    product_name: Optional[str] = None
    window_hours: int
    temp_stats: BandStats
    hum_stats: BandStats
    health_score: Optional[float]
    health_status: str
    class_probabilities: dict[str, float]
    time_window: dict[str, str]

    class Config:
        from_attributes = True
