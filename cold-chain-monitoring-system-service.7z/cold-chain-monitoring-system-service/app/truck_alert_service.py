# app/truck_alert_service.py
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from .llm_service import get_llm
from langchain_google_genai import ChatGoogleGenerativeAI
from sqlalchemy.orm import Session
from . import models

def explain_truck_sensor_breach(result: Dict[str, Any]) -> str:
    """
    Use LLM to turn the numeric breach result into a short explanation.
    Safe to call only after check_truck_sensor_breach.
    """
    llm: ChatGoogleGenerativeAI = get_llm()

    prompt = f"""
You are an operations assistant for a cold-chain logistics control tower.

Given this JSON describing a truck-level sensor status, write a brief explanation
(2–3 sentences, plain English, no JSON) for ops staff. If breach=false, say the
sensor is within limits and how close it is. If breach=true, explain how long it
has been out of range, whether it's above or below, and what immediate action
they should consider.

JSON:
{result}
"""

    resp = llm.invoke(prompt)
    return resp.text.strip()

def _is_out_of_range(value: float, min_v: Optional[float], max_v: Optional[float]) -> bool:
    if min_v is not None and value < min_v:
        return True
    if max_v is not None and value > max_v:
        return True
    return False


def check_truck_sensor_breach(
    db: Session,
    sensor_id: int,
    lookback_minutes: int = 60,
) -> Dict[str, Any]:
    """
    Returns whether this truck sensor has been continuously out of range
    for at least breach_window_seconds.
    """
    sensor = db.query(models.Sensor).filter(models.Sensor.sensor_id == sensor_id).first()
    if sensor is None:
        return {"error": "sensor_not_found"}

    if sensor.sensor_scope != models.SensorScope.VEHICLE:
        return {"error": "not_a_truck_sensor"}

    if sensor.min_value is None and sensor.max_value is None:
        return {"error": "threshold_not_configured"}

    if sensor.breach_window_seconds is None:
        return {"error": "breach_window_not_configured"}

    now = datetime.utcnow()
    start = now - timedelta(minutes=lookback_minutes)

    readings: List[models.SensorData] = (
        db.query(models.SensorData)
        .filter(models.SensorData.sensor_id == sensor_id)
        .filter(models.SensorData.recorded_at >= start)
        .order_by(models.SensorData.recorded_at.asc())
        .all()
    )

    # Common fields
    base = {
        "sensor_id": sensor_id,
        "sensor_code": sensor.sensor_code,
        "sensor_kind": sensor.sensor_kind.value,
        "min_value": float(sensor.min_value) if sensor.min_value is not None else None,
        "max_value": float(sensor.max_value) if sensor.max_value is not None else None,
        "breach_window_seconds": sensor.breach_window_seconds,
    }

    if not readings:
        return {
            **base,
            "breach": False,
            "breach_duration_seconds": None,
            "breach_start": None,
            "breach_end": None,
            "reason": "no_data",
        }

    # Walk from newest backwards until we find an in-range point.
    breach_start: Optional[datetime] = None
    breach_end: Optional[datetime] = None

    for r in reversed(readings):
        if r.value_number is None:
            continue

        v = float(r.value_number)
        if _is_out_of_range(
            v,
            float(sensor.min_value) if sensor.min_value is not None else None,
            float(sensor.max_value) if sensor.max_value is not None else None,
        ):
            breach_end = breach_end or r.recorded_at
            breach_start = r.recorded_at
        else:
            if breach_end is not None:
                break

    if breach_start is None or breach_end is None:
        # latest readings are in range
        return {
            **base,
            "breach": False,
            "breach_duration_seconds": None,
            "breach_start": None,
            "breach_end": None,
            "reason": "in_range",
        }

    duration = (breach_end - breach_start).total_seconds()
    required = sensor.breach_window_seconds

    return {
        **base,
        "breach": duration >= required,
        "breach_duration_seconds": round(duration, 1),
        "breach_start": breach_start.isoformat(),
        "breach_end": breach_end.isoformat(),
        "reason": "breach_window_exceeded" if duration >= required else "below_threshold_duration",
    }
