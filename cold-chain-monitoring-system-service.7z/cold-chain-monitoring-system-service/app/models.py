from sqlalchemy import Column, BigInteger, String, Enum, DECIMAL, ForeignKey, Boolean, DateTime, JSON
from sqlalchemy.orm import relationship
from .database import Base
import enum

class Trip(Base):
    __tablename__ = "trip"

    trip_id = Column(BigInteger, primary_key=True, autoincrement=True)
    truck_id = Column(BigInteger, ForeignKey("truck.truck_id"), nullable=False)
    trip_code = Column(String(64), unique=True, nullable=False)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime)
    start_lat = Column(DECIMAL(10, 6))
    start_lng = Column(DECIMAL(10, 6))
    end_lat = Column(DECIMAL(10, 6))
    end_lng = Column(DECIMAL(10, 6))
    status = Column(Enum("PLANNED", "IN_PROGRESS", "COMPLETED", "CANCELLED", name="trip_status"), nullable=False, default="IN_PROGRESS")
    is_active = Column(Boolean, nullable=False, default=True)

    truck = relationship("Truck", backref="trips")

class SensorScope(str, enum.Enum):
    VEHICLE = "VEHICLE"
    PACKAGE = "PACKAGE"

class SensorKind(str, enum.Enum):
    TEMPERATURE = "TEMPERATURE"
    HUMIDITY = "HUMIDITY"
    GPS = "GPS"

class Truck(Base):
    __tablename__ = "truck"

    truck_id = Column(BigInteger, primary_key=True, autoincrement=True)
    truck_code = Column(String(64), unique=True, nullable=False)
    registration_number = Column(String(64))
    description = Column(String(255))
    capacity_kg = Column(DECIMAL(10, 2))

    sensors = relationship("Sensor", back_populates="truck")
    truck_packages = relationship("TruckPackage", back_populates="truck")

class Package(Base):
    __tablename__ = "package"

    package_id = Column(BigInteger, primary_key=True, autoincrement=True)
    package_code = Column(String(64), unique=True, nullable=False)
    order_id = Column(String(64))
    batch_id = Column(String(64))
    product_sku = Column(String(64))
    product_name = Column(String(255))
    description = Column(String(255))

    # NEW: per‑package thresholds
    min_temp_c = Column(DECIMAL(5, 2))       # e.g. 2.00
    max_temp_c = Column(DECIMAL(5, 2))       # e.g. 8.00
    min_humidity_pc = Column(DECIMAL(5, 2))  # e.g. 60.00 (%)
    max_humidity_pc = Column(DECIMAL(5, 2))  # e.g. 85.00 (%)

    sensors = relationship("Sensor", back_populates="package")
    truck_packages = relationship("TruckPackage", back_populates="package")


class SensorType(Base):
    __tablename__ = "sensor_type"

    sensor_type_id = Column(BigInteger, primary_key=True, autoincrement=True)
    name = Column(String(64), unique=True, nullable=False)
    manufacturer = Column(String(128))
    model = Column(String(128))
    measurement_unit = Column(String(32))
    description = Column(String(255))

class Sensor(Base):
    __tablename__ = "sensor"

    sensor_id = Column(BigInteger, primary_key=True, autoincrement=True)
    sensor_code = Column(String(64), unique=True, nullable=False)
    sensor_scope = Column(Enum(SensorScope), nullable=False)
    sensor_kind = Column(Enum(SensorKind), nullable=False)

    # NEW:
    min_value = Column(DECIMAL(6, 2))          # per-sensor lower limit
    max_value = Column(DECIMAL(6, 2))          # per-sensor upper limit
    breach_window_seconds = Column(BigInteger)    # duration threshold (seconds)

    sensor_type_id = Column(BigInteger, ForeignKey("sensor_type.sensor_type_id"))
    truck_id = Column(BigInteger, ForeignKey("truck.truck_id"))
    package_id = Column(BigInteger, ForeignKey("package.package_id"))
    is_active = Column(Boolean, nullable=False, default=True)
    installed_at = Column(DateTime)
    removed_at = Column(DateTime)

    truck = relationship("Truck", back_populates="sensors")
    package = relationship("Package", back_populates="sensors")
    sensor_data = relationship("SensorData", back_populates="sensor")


class SensorData(Base):
    __tablename__ = "sensor_data"

    sensor_data_id = Column(BigInteger, primary_key=True, autoincrement=True)
    sensor_id = Column(BigInteger, ForeignKey("sensor.sensor_id"), nullable=False)
    recorded_at = Column(DateTime, nullable=False)
    value_number = Column(DECIMAL(10, 3))
    value_lat = Column(DECIMAL(10, 6))
    value_lng = Column(DECIMAL(10, 6))
    raw_payload = Column(JSON)

    sensor = relationship("Sensor", back_populates="sensor_data")

class TruckPackage(Base):
    __tablename__ = "truck_package"

    truck_package_id = Column(BigInteger, primary_key=True, autoincrement=True)
    truck_id = Column(BigInteger, ForeignKey("truck.truck_id"), nullable=False)
    package_id = Column(BigInteger, ForeignKey("package.package_id"), nullable=False)
    loaded_at = Column(DateTime, nullable=False)
    unloaded_at = Column(DateTime)

    truck = relationship("Truck", back_populates="truck_packages")
    package = relationship("Package", back_populates="truck_packages")
